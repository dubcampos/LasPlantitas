package com.codigo.recplants.clases;

import android.widget.TextView;

public class prueba {
    String tx1;
    String tx2;

    public prueba(String tx1, String tx2) {
        this.tx1 = tx1;
        this.tx2 = tx2;
    }

    public String getTx1() {
        return tx1;
    }

    public void setTx1(String tx1) {
        this.tx1 = tx1;
    }

    public String getTx2() {
        return tx2;
    }

    public void setTx2(String tx2) {
        this.tx2 = tx2;
    }
}
